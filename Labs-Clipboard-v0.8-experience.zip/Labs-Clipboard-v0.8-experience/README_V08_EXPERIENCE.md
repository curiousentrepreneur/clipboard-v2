# Labs Clipboard v0.8 — Experience

Bu sürümde odak: kullanıcı deneyimi.

## Yeni eklenenler
- Alınan dosyalar bölümü güçlendirildi.
- Dosya simgeleri eklendi.
- Dosya boyutu, gönderen cihaz ve saat gösteriliyor.
- Dosyada arama eklendi.
- Dosya favorileme eklendi.
- Dosya aç / klasör aç / kaydı sil butonları eklendi.
- Pano geçmişinde arama eklendi.
- v0.7 güvenlik ve log sistemi korunuyor.

## Test
1. İki cihazda v0.8 çalıştır.
2. Eşleştir.
3. Önce karttaki Test butonuna bas.
4. Metin gönder.
5. Dosya gönder.
6. Alınan Dosyalar panelinde dosyanın görünüp görünmediğine bak.
