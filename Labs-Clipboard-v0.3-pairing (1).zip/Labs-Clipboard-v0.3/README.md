# Labs Clipboard v0.3

Güvenli yerel ağ panosu. Metin, görsel ve dosya aktarımı için deneysel sürüm.

## v0.3 yenilikleri

- Eşleştirme süresi 10 dakikaya çıkarıldı.
- Otomatik cihaz bulup PIN ile eşleşme eklendi.
- Manuel IP/QR ile eşleşme güçlendirildi.
- Eşleştirme hata mesajları daha anlaşılır hâle getirildi.
- Alınan dosyalar bölümü korunuyor: Aç / Klasör / Sil.
- Python 3.14 Tk font hatası için ondalıklı font boyutları temizlendi.

## Çalıştırma

Windows:

```bat
run_windows.bat
```

Sorun çıkarsa klasik arayüz:

```bat
run_classic_windows.bat
```

## Eşleştirme

1. İki cihaz aynı Wi-Fi/ağda olsun.
2. İki cihazda da uygulama açık olsun.
3. PIN gösterecek cihazda `+ Cihaz ekle > Bu cihazda PIN` açık kalsın.
4. Diğer cihazda `+ Cihaz ekle > Bağlan` sekmesine geç.
5. PIN'i yazıp `Otomatik bul ve eşleş` tuşuna bas.
6. Otomatik olmazsa listeden cihaz seç veya manuel IP gir.

Not: Windows Güvenlik Duvarı izin isterse izin ver.
