# Labs Clipboard v0.7 — Stability & Security

Bu sürümde ana hedef: çalışan temeli güvenli ve daha stabil hâle getirmek.

## Yenilikler
- Debug amaçlı **PIN'siz acil test eşleştirme** kaldırıldı.
- Eşleştirme akışı güvenli PIN/QR tarafına toplandı.
- Cihaz IP kaydı korunuyor; discovery çalışmasa bile gönderim deneniyor.
- Cihaz kartındaki **Test** butonu duruyor.
- Log sistemi eklendi: `C:\Users\<kullanıcı>\.labs_clipboard\labs_clipboard.log`
- Arayüze **Log klasörü** butonu eklendi.
- Hata mesajları daha anlaşılır hâle getirildi.
- Uygulama adı v0.7 olarak güncellendi.

## Test sırası
1. İki bilgisayarda eski Labs/Pano uygulamalarını tamamen kapat.
2. Bu paketi iki bilgisayarda da çalıştır.
3. Eski eşleşmeler karışırsa cihazları kaldırıp yeniden eşleştir.
4. Karttaki **Test** butonuna bas.
5. Panodaki metin ve dosya gönderimini dene.
6. Sorun olursa **Log klasörü** butonuyla logu açıp hatayı gönder.

## Not
v0.7 yeni özellikten çok temel sağlamlaştırma sürümüdür.
