# Labs Clipboard v0.9 — Smart Actions

Bu sürümde odak: akıllı pano deneyimi.

## Yeni eklenenler
- Kopyalanan içerik türü algılanır.
- Link algılama: tarayıcıda aç.
- E-posta algılama: mail yaz.
- Telefon algılama: ara / temiz numara kopyala.
- Adres olabilecek metin: haritada aç.
- Kod/çok satırlı metin: boşlukları temizle.
- Uzun metin: tek satıra çevir.
- v0.8 dosya merkezi ve arama korunur.
- v0.7 güvenlik/log sistemi korunur.

## Test önerisi
Şunları sırayla kopyala:
- https://chat.openai.com
- test@example.com
- +90 555 123 45 67
- İstanbul Bağdat Caddesi
- birkaç satırlık kod


---

# Labs Clipboard v0.8 — Experience

Bu sürümde odak: kullanıcı deneyimi.

## Yeni eklenenler
- Alınan dosyalar bölümü güçlendirildi.
- Dosya simgeleri eklendi.
- Dosya boyutu, gönderen cihaz ve saat gösteriliyor.
- Dosyada arama eklendi.
- Dosya favorileme eklendi.
- Dosya aç / klasör aç / kaydı sil butonları eklendi.
- Pano geçmişinde arama eklendi.
- v0.7 güvenlik ve log sistemi korunuyor.

## Test
1. İki cihazda v0.8 çalıştır.
2. Eşleştir.
3. Önce karttaki Test butonuna bas.
4. Metin gönder.
5. Dosya gönder.
6. Alınan Dosyalar panelinde dosyanın görünüp görünmediğine bak.


---

# Labs Clipboard v0.7 — Stability & Security

Bu sürümde ana hedef: çalışan temeli güvenli ve daha stabil hâle getirmek.

## Yenilikler
- Debug amaçlı **PIN'siz acil test eşleştirme** kaldırıldı.
- Eşleştirme akışı güvenli PIN/QR tarafına toplandı.
- Cihaz IP kaydı korunuyor; discovery çalışmasa bile gönderim deneniyor.
- Cihaz kartındaki **Test** butonu duruyor.
- Log sistemi eklendi: `C:\Users\<kullanıcı>\.labs_clipboard\labs_clipboard.log`
- Arayüze **Log klasörü** butonu eklendi.
- Hata mesajları daha anlaşılır hâle getirildi.
- Uygulama adı v0.7 olarak güncellendi.

## Test sırası
1. İki bilgisayarda eski Labs/Pano uygulamalarını tamamen kapat.
2. Bu paketi iki bilgisayarda da çalıştır.
3. Eski eşleşmeler karışırsa cihazları kaldırıp yeniden eşleştir.
4. Karttaki **Test** butonuna bas.
5. Panodaki metin ve dosya gönderimini dene.
6. Sorun olursa **Log klasörü** butonuyla logu açıp hatayı gönder.

## Not
v0.7 yeni özellikten çok temel sağlamlaştırma sürümüdür.


---

# Labs Clipboard v0.4 Pairing Clean

Bu sürüm eşleştirme için yeni ağ portlarını kullanır: UDP 47900 / TCP 47901.

Önemli: İki bilgisayarda da eski Labs/Pano sürümlerini kapatın. Sistem tepsisinde gizli kalmış olabilir. Sonra bu v0.4 paketini iki cihazda da çalıştırın.

Çalıştırma: `run_windows.bat`

Eşleştirme:
1. Ana cihazda `+ Cihaz ekle` > `Bu cihazda PIN` açık kalsın.
2. Diğer cihazda `+ Cihaz ekle` > `Bağlan` sekmesinde PIN yazın.
3. Otomatik bul ve eşleş veya manuel IP ile eşleş.

Alınan dosyalar bölümü bu pakette dahildir.
