# Labs Clipboard v0.9 — Smart Actions

Bu sürümde odak: akıllı pano deneyimi.

## Yeni eklenenler
- Kopyalanan içerik türü algılanır.
- Link algılama: tarayıcıda aç.
- E-posta algılama: mail yaz.
- Telefon algılama: ara / temiz numara kopyala.
- Adres olabilecek metin: haritada aç.
- Kod/çok satırlı metin: boşlukları temizle.
- Uzun metin: tek satıra çevir.
- v0.8 dosya merkezi ve arama korunur.
- v0.7 güvenlik/log sistemi korunur.

## Test önerisi
Şunları sırayla kopyala:
- https://chat.openai.com
- test@example.com
- +90 555 123 45 67
- İstanbul Bağdat Caddesi
- birkaç satırlık kod
